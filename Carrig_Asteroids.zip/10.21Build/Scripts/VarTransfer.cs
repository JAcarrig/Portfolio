﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class VarTransfer{

    private static bool kmode = false;

    public static bool Kmode { get { return kmode; } set { kmode = value; } }
}
